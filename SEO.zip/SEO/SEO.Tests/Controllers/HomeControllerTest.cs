﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SEO;
using SEO.Controllers;
using SEO.Models;

namespace SEO.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
            HomeController controller = new HomeController();

            // Act
            //ViewResult result = controller.Index() as ViewResult;

            SEOViewModel viewModel = new SEOViewModel();

            viewModel.SearchType = "U";
            viewModel.SearchString = "https://www.sitecore.com/company/contact-us";
            viewModel.AnalysisOptionsM = true;
            viewModel.AnalysisOptionsL = true;
            viewModel.AnalysisOptionsP = true;

            JsonResult result = controller.GenerateResult(viewModel) as JsonResult;

            // Assert
            Assert.IsNotNull(result);
        }

        
    }
}
