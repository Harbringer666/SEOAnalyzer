﻿using CommonServices.Interfaces;
using CommonServices.Services;
using SEO.Models;
using SEO.Models.System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace SEO.Controllers
{
    public class HomeController : Controller
    {
        public IValidatePageService _ValidatePageService;

        public IValidatePageService ValidatePageService
        {
            get
            {
                if (_ValidatePageService == null)
                    _ValidatePageService = new ValidatePageService();

                return _ValidatePageService;
            }
            set
            {
                _ValidatePageService = value;
            }
        }

        public IValidateMetaTagService _ValidateMetaTagService; 

        public IValidateMetaTagService ValidateMetaTagService
        {
            get
            {
                if (_ValidateMetaTagService == null)
                    _ValidateMetaTagService = new ValidateMetaTagService();

                return _ValidateMetaTagService;
            }
            set
            {
                _ValidateMetaTagService = value;
            }
        }

        public IValidateExternalLinkService _ValidateExternalLinkService;

        public IValidateExternalLinkService ValidateExternalLinkService
        {
            get
            {
                if (_ValidateExternalLinkService == null)
                    _ValidateExternalLinkService = new ValidateExternalLinkService();

                return _ValidateExternalLinkService;
            }
            set
            {
                _ValidateExternalLinkService = value;
            }
        }

        public ActionResult About()
        {
            if (Request.IsAjaxRequest())
            {
                return PartialView();
            }
            else
            {
                return View();
            }
        }

        public ActionResult Index()
        {
            SEOViewModel viewModel = new SEOViewModel();

            viewModel.SearchString = "http://localhost:50641/Home/About";
            viewModel.AnalysisOptionsP = viewModel.AnalysisOptionsM = viewModel.AnalysisOptionsL = true;

            if (Request.IsAjaxRequest())
            {
                return PartialView(viewModel);
            }
            else
            {
                return View(viewModel);
            }
        }

        public List<string> ValidateURL(string url)
        {
            List<string> errors = new List<string>();

            if (!String.IsNullOrEmpty(url))
            {
                if (ValidateService.CheckURLValidity(url))
                {
                    // determine whether the url responding or not
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                    request.Timeout = 15000;
                    request.Method = "HEAD";
                    try
                    {
                        using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                        {
                            if (response.StatusCode != HttpStatusCode.OK)
                            {
                                errors.Add("No Response from the site");
                            }
                        }
                    }
                    catch (WebException)
                    {
                        errors.Add("Server not responding.");
                    }

                }
                else
                {
                    errors.Add("Not Valid URL/site");
                }
            }
            else
            {
                errors.Add("Url cannot be empty");
            }
            
            return errors;
        }

        [HttpPost]
        public JsonResult GenerateResult(SEOViewModel viewModel)
        {
            JsonModel jsonModel = new JsonModel();
            string htmlCode = "";
            List<SEOTabularViewModel> tabulars = new List<SEOTabularViewModel>();
            List<string> errors = new List<string>();
            
            try
            {
                // decode url
                viewModel.SearchString = HttpUtility.UrlDecode(viewModel.SearchString);
                if (viewModel.SearchType == "U") // search bu url
                {
                     errors = ValidateURL(viewModel.SearchString);

                    if(errors.Count == 0)
                    {
                        using (WebClient client = new WebClient())
                        {
                            htmlCode = client.DownloadString(viewModel.SearchString);
                        }
                    }
                    else
                    {
                        jsonModel.IsSuccess = false;
                        jsonModel.ErrorMessage = errors;

                        return Json(jsonModel);
                    }
                    
                }
                else
                {
                    htmlCode = viewModel.SearchString;
                }

                if (viewModel.AnalysisOptionsM)
                    tabulars.AddRange(ValidateMetaTagService.GetNumberOfOccuranceInMetaData(htmlCode));

                if (viewModel.AnalysisOptionsP)
                    tabulars.AddRange(ValidatePageService.GetNumberOfOccuranceInPage(htmlCode));

                if (viewModel.AnalysisOptionsL)
                {
                    string baseUrl = string.Empty;

                    if (viewModel.SearchType == "U")
                    {
                        var uri = new Uri(viewModel.SearchString);
                        baseUrl = uri.Host;
                    }
                    
                    tabulars.AddRange(ValidateExternalLinkService.GetNumberOfExternalLink(htmlCode, baseUrl));
                }
                    
                // update key to show meaningfull words
                tabulars.ForEach(x =>
                {
                    if (x.AnalysisOptType == "M")
                    {
                        x.AnalysisOptType = "Meta Type";
                    }
                    else if (x.AnalysisOptType == "P")
                    {
                        x.AnalysisOptType = "Page";
                    }
                    else if (x.AnalysisOptType == "L")
                    {
                        x.AnalysisOptType = "External Link";
                    }
                });

            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                errors.Add("Invalid Input (Text must be in HTML format)");
            }

            if (errors.Count == 0)
            {
                jsonModel.IsSuccess = true;
                jsonModel.Data = tabulars;
            }
            else
            {
                jsonModel.IsSuccess = false;
                jsonModel.ErrorMessage = errors;
            }

            return Json(jsonModel);
        }
        
    }
}