﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEO.Models.System
{
    public class JsonModel
    {
        public bool IsSuccess { get; set; }
        public dynamic Data { get; set; }
        public List<string> ErrorMessage { get; set; }
    }
}