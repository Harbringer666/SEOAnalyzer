﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEO.Models
{
    public class SEOViewModel
    {
        private string _SearchType;

        public string SearchType
        {
            get { return _SearchType; }
            set { _SearchType = value; }
        }

        private string _SearchString;

        public string SearchString
        {
            get { return _SearchString; }
            set { _SearchString = value; }
        }

        private bool _AnalysisOptionsP;

        public bool AnalysisOptionsP
        {
            get { return _AnalysisOptionsP; }
            set { _AnalysisOptionsP = value; }
        }

        private bool _AnalysisOptionsM;

        public bool AnalysisOptionsM
        {
            get { return _AnalysisOptionsM; }
            set { _AnalysisOptionsM = value; }
        }

        private bool _AnalysisOptionsL;

        public bool AnalysisOptionsL
        {
            get { return _AnalysisOptionsL; }
            set { _AnalysisOptionsL = value; }
        }
    }
}