﻿using SEO.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CommonServices.Interfaces
{
    public interface IValidateExternalLinkService
    {
        List<SEOTabularViewModel> GetNumberOfExternalLink(string html, string baseURL);
    }
}
