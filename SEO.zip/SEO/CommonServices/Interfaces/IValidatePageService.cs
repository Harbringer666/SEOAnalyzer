﻿using SEO.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CommonServices.Interfaces
{
    public interface IValidatePageService
    {
        List<SEOTabularViewModel> GetNumberOfOccuranceInPage(string html);
    }
}
