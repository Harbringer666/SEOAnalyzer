﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonServices.Interfaces
{
    public class IValidateBase
    {
    }
}
