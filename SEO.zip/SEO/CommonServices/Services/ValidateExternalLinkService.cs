﻿using CommonServices.Interfaces;
using SEO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonServices.Services
{
    public class ValidateExternalLinkService: ValidateBase,IValidateExternalLinkService
    {
        public List<SEOTabularViewModel> GetNumberOfExternalLink(string html, string baseURL)
        {
            int bodyTagLength = "<body".Length;
            string body = html.Substring(html.IndexOf("<body") + bodyTagLength, html.LastIndexOf("</body>") - html.IndexOf("<body") - bodyTagLength).ToString();
            List<SEOTabularViewModel> tabularViews = new List<SEOTabularViewModel>();
            List<string> externalLinks = new List<string>();

            if (!string.IsNullOrEmpty(baseURL))
            {
                externalLinks = body.Split(new char[] { '<', '>' }, StringSplitOptions.RemoveEmptyEntries).Where(x => x.Length >= 2 && x.Substring(0, 2) == "a "
           && !x.ToLower().Contains(baseURL.ToLower())).ToList();
            }
            else
            {
                externalLinks = body.Split(new char[] { '<', '>' }, StringSplitOptions.RemoveEmptyEntries).Where(x => x.Length >= 2 && x.Substring(0, 2) == "a ").ToList();
            }
           

            SEOTabularViewModel tabular = new SEOTabularViewModel();

            tabular.AnalysisOptType = "L";
            tabular.NumberOfOccurance = externalLinks.Count;
            tabular.StopWord = "-";

            tabularViews.Add(tabular);

            return tabularViews;
        }
    }
}
