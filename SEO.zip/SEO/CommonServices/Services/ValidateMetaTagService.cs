﻿using CommonServices.Interfaces;
using SEO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonServices.Services
{
    public class ValidateMetaTagService: ValidateBase, IValidateMetaTagService
    {
        public List<SEOTabularViewModel> GetNumberOfOccuranceInMetaData(string html)
        {
            List<SEOTabularViewModel> tabularViews = new List<SEOTabularViewModel>();
            List<string> metas = html.Split(new char[] { '<', '>' }, StringSplitOptions.RemoveEmptyEntries).Where(x => x.Length >= 4 && x.Substring(0, 4) == "meta").ToList();

            foreach (string word in stopWords)
            {
                int noOfOccurance = 0;

                noOfOccurance = metas.Where(x => x.Split(' ').ToList().Contains(word)).Count();

                if (noOfOccurance > 0)
                {
                    SEOTabularViewModel tabular = new SEOTabularViewModel();

                    tabular.AnalysisOptType = "M";
                    tabular.NumberOfOccurance = noOfOccurance;
                    tabular.StopWord = word;

                    tabularViews.Add(tabular);
                }

            }

            return tabularViews;
        }
    }
}
