﻿using CommonServices.Interfaces;
using SEO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonServices.Services
{
    public class ValidatePageService : ValidateBase,IValidatePageService
    {
        public List<SEOTabularViewModel> GetNumberOfOccuranceInPage(string html)
        {
            int bodyTagLength = "<body".Length;
            string body = html.Substring(html.IndexOf("<body") + bodyTagLength, html.LastIndexOf("</body>") - html.IndexOf("<body") - bodyTagLength).ToString();
            List<SEOTabularViewModel> tabularViews = new List<SEOTabularViewModel>();

            foreach (string word in stopWords)
            {
                int noOfOccurance = 0;

                noOfOccurance = body.Split(' ').ToList().Where(x => x.ToLower() == word.ToLower()).Count();

                if (noOfOccurance > 0)
                {
                    SEOTabularViewModel tabular = new SEOTabularViewModel();

                    tabular.AnalysisOptType = "P";
                    tabular.NumberOfOccurance = noOfOccurance;
                    tabular.StopWord = word;

                    tabularViews.Add(tabular);
                }

            }

            return tabularViews;
        }
    }
}
