﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonServices.Services
{
    public static class ValidateService
    {
        public static bool CheckURLValidity(string url)
        {
            Uri uriResult;

            return Uri.TryCreate(url, UriKind.Absolute, out uriResult) && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);
        }
    }
}
