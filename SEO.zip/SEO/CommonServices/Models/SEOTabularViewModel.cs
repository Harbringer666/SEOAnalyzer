﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEO.Models
{
    public class SEOTabularViewModel
    {
        private string _StopWord;

        public string StopWord
        {
            get { return _StopWord; }
            set { _StopWord = value; }
        }

        private int _NumberOfOccurance;

        public int NumberOfOccurance
        {
            get { return _NumberOfOccurance; }
            set { _NumberOfOccurance = value; }
        }

        private string _AnalysisOptType;

        public string AnalysisOptType
        {
            get { return _AnalysisOptType; }
            set { _AnalysisOptType = value; }
        }

    }
}